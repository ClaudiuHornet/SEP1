/*globals XMLHttpRequest: false, window: false*/

var xmlDoc, document;
var day = 1;
var finishedInsertingMonth = false;
var justStartingMonth = true;

function lastDayOfTheMonth(month, year){
    var isLeapYear = false;
    if (year % 4 == 0){
        if (year % 100 == 0){
            if (year % 400 == 0){
                isLeapYear = true;
                }
            else{
                isLeapYear = false;
                }
            }
        else{
            isLeapYear = true;
            }
        }
    else{
      isLeapYear = false;
    }

    if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8
        || month == 10 || month == 12)
    {
      return 31;
    }
    else if (month == 4 || month == 6 || month == 9 || month == 11)
    {
      return 30;
    }
    else if (month == 2)
    {
      if (isLeapYear)
      {
        return 29;
      }
      else
      {
        return 28;
      }
    }
    else {
      return 0;
    }
  }

function getDayOfMonth(day, month, year){
    var q, m, k, j, h;
    q = day;
    switch(month){
        case 1:
            m = 13;
            year -= 1;
            break;
        case 2:
            m = 14;
            year -= 1;
            break;
        case 3:
            m = 3;
            break;
        case 4:
            m = 4;
            break;
        case 5:
            m = 5;
            break;
        case 6:
            m = 6;
            break;
        case 7:
            m = 7;
            break;
        case 8:
            m = 8;
            break;
        case 9:
            m = 9;
            break;
        case 10:
            m = 10;
            break;
        case 11:
            m = 1;
            break;
        case 12:
            m = 12;
            break;
        }
    k = year % 100;
    j = parseInt(year / 100);
    h = parseInt((q + 13 * (m + 1) / 5 + k + k / 4 + j / 4 + 5 * j) % 7);
    switch (h) {
        case 0:
            return "Saturday";
        case 1:
            return "Sunday";
        case 2:
            return "Monday";
        case 3:
            return "Tuesday";
        case 4:
            return "Wednesday";
        case 5:
            return "Thursday";
        case 6:
            return "Friday";
        default:
            return h;
        }
    }
            
function getStartingPosition(month, year){
    switch(getDayOfMonth(1, month, year)){
        case "Monday":
            return 0;
        case "Tuesday":
            return 1;
        case "Wednesday":
            return 2;
        case "Thursday":
            return 3;
        case "Friday":
            return 4;
        case "Saturday":
            return 5;
        case "Sunday":
            return 6;
    }
}

function insertDay(day){
    return "<div class=\"col-6 col-md-1 pb-3 pb-md-4 pt-0 border-right border-bottom border-left dayDiv\"><p class=\"text-muted d-inline small\">" + day + "</p><p class=\"text-center text-muted mb-0\">No classes</p><p class=\"text-center text-muted mb-0 font-weight-bold\">available</p><p class=\"text-center text-muted mb-0\"></p></div>";
}

function insertWeekRow(day, month, year){
    var scheduleDiv = document.getElementById("schedule");
    if (day == 1){
        scheduleDiv.innerHTML = "";
    }
    else {
        justStartingMonth = false;
    }
    var stringToInsert = "";
    
    stringToInsert += "<div class=\"row mx-0 justify-content-between bg-gray-light\">";
    for (var i = 0; i < 7; i++){
        if ( justStartingMonth == true && i < getStartingPosition(month, year)){
            stringToInsert += insertDay(lastDayOfTheMonth(month - 1, year) - getStartingPosition(month, year) +1 +i);
        }
        else{
            if (window.day <= lastDayOfTheMonth(month, year)){
            stringToInsert += insertDay(window.day);
            window.day++;
        }
        else {
            finishedInsertingMonth = true;
            window.day = 1;
            stringToInsert += insertDay(window.day);
            window.day ++;
        }
        }
        
    }

    stringToInsert += "</div>";
    
    scheduleDiv.innerHTML += stringToInsert;
}

function getMonthName(month){
    switch(month){
        case 1:
            return "January";
        case 2:
            return "February";
        case 3:
            return "March";
        case 4:
            return "April";
        case 5:
            return "May";
        case 6:
            return "June";
        case 7:
            return "July";
        case 8:
            return "August";
        case 9:
            return "September";
        case 10:
            return "October";
        case 11:
            return "November";
        case 12:
            return "December";
    }
}

function displayContent(xml){
    xmlDoc = xml.responseXML;
    
    var classNames = xmlDoc.getElementsByTagName("name");
    var timeHours = xmlDoc.getElementsByTagName("hour");
    var timeMinutes = xmlDoc.getElementsByTagName("minute");
    var instructors = xmlDoc.getElementsByTagName("firstName");
    var daysXML = xmlDoc.getElementsByTagName("day");
    var scheduleMonth = xmlDoc.getElementsByTagName("month")[0].childNodes[0].nodeValue;
    var scheduleYear = xmlDoc.getElementsByTagName("year")[0].childNodes[0].nodeValue;
    
    var days = document.getElementsByClassName("dayDiv");
    var monthYearDiv = document.getElementById("monthYearDiv");

    monthYearDiv.innerHTML = getMonthName(parseInt(scheduleMonth, 10)) + " " + scheduleYear;
    
    function hasClassOnDate(date){
        for (var i = 0; i < daysXML.length; i++){
                if (daysXML[i].childNodes[0].nodeValue == date)
                    return true;
            }
        return false;
    }
    
    while (!finishedInsertingMonth){
    insertWeekRow(window.day, parseInt(scheduleMonth, 10), parseInt(scheduleYear, 10));
    }
    
    var arrayItem = 0;
    for (var i = 0; i < days.length; i++)
    {
        if(hasClassOnDate(days[i].getElementsByTagName("p")[0].childNodes[0].nodeValue)){
            days[i].getElementsByTagName("p")[1].innerHTML = timeHours[arrayItem].childNodes[0].nodeValue + ":" + timeMinutes[arrayItem].childNodes[0].nodeValue;
            days[i].getElementsByTagName("p")[2].innerHTML = classNames[arrayItem].childNodes[0].nodeValue;
            days[i].getElementsByTagName("p")[2].classList.add("orangeText");
            days[i].getElementsByTagName("p")[3].innerHTML =instructors[arrayItem].childNodes[0].nodeValue;
            arrayItem=arrayItem+1;
            }
    }
}

function readXML() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            displayContent(this);
        }
    };
    xhttp.open("GET", "xml/scheduleExport.xml", true);
    xhttp.send();
}

readXML();
